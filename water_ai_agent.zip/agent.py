import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

THRESHOLD = 0.15

class WaterQualityAgent:
    def __init__(self):
        self.model = load_model("model.h5")
        self.scaler = MinMaxScaler()

    def predict(self, data):
        data_scaled = self.scaler.fit_transform(data)
        X = np.array([data_scaled[-3:]])
        pred = self.model.predict(X)
        return self.scaler.inverse_transform(pred)[0][0]

    def analyze(self, df):
        mn_values = df[['Mn']].values
        prediction = self.predict(mn_values)

        if prediction > THRESHOLD:
            status = "⚠️ 预警：未来锰浓度可能超标"
        else:
            status = "✅ 水质正常"

        return {
            "prediction": prediction,
            "status": status
        }
