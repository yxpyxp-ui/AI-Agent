import streamlit as st
import pandas as pd
from agent import WaterQualityAgent

st.title("🌊 AI水质预测与预警系统")

uploaded_file = st.file_uploader("上传水质数据（CSV）")

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.write("数据预览", df)

    agent = WaterQualityAgent()
    result = agent.analyze(df)

    st.subheader("📈 预测结果")
    st.write(f"未来锰浓度预测值: {result['prediction']:.3f}")

    st.subheader("🚨 预警状态")
    st.write(result['status'])
