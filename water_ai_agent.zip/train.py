import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

df = pd.read_csv("data.csv")
data = df[['Mn']].values

scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data)

def create_dataset(data, time_step=3):
    X, y = [], []
    for i in range(len(data)-time_step):
        X.append(data[i:i+time_step])
        y.append(data[i+time_step])
    return np.array(X), np.array(y)

X, y = create_dataset(data_scaled)

model = Sequential([
    LSTM(50, return_sequences=True, input_shape=(3,1)),
    LSTM(50),
    Dense(1)
])

model.compile(optimizer='adam', loss='mse')
model.fit(X, y, epochs=50, verbose=1)

model.save("model.h5")
print("模型训练完成")
