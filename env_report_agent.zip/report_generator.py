class ReportGenerator:
    def __init__(self, stats, anomalies, trends):
        self.stats = stats
        self.anomalies = anomalies
        self.trends = trends

    def generate(self):
        report = []
        report.append("=== 环境化学实验数据分析报告 ===\n")

        report.append("【1. 数据统计】")
        report.append(str(self.stats))

        report.append("\n【2. 趋势分析】")
        for k, v in self.trends.items():
            direction = "上升" if v > 0 else "下降"
            report.append(f"{k}: {direction} ({v:.3f})")

        report.append("\n【3. 异常检测】")
        for k, v in self.anomalies.items():
            if len(v) > 0:
                report.append(f"{k}: 存在异常值")
            else:
                report.append(f"{k}: 正常")

        report.append("\n【4. 结论】")
        report.append("水质整体趋势需重点关注Mn与COD变化，建议加强监测。")

        return "\n".join(report)
