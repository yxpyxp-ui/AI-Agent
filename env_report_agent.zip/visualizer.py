import matplotlib.pyplot as plt

class Visualizer:
    def __init__(self, df):
        self.df = df

    def plot_all(self):
        for col in ["pH", "Mn", "COD"]:
            plt.figure()
            plt.plot(self.df["date"], self.df[col])
            plt.title(f"{col} Trend")
            plt.xticks(rotation=45)
            plt.tight_layout()
            plt.savefig(f"{col}.png")
            plt.close()
