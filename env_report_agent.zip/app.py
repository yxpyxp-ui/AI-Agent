import streamlit as st
from agent import EnvDataAgent

st.title("🧪 环境化学实验数据分析与报告系统")

uploaded_file = st.file_uploader("上传实验数据 CSV")

if uploaded_file:
    with open("temp.csv", "wb") as f:
        f.write(uploaded_file.read())

    agent = EnvDataAgent("temp.csv")
    report = agent.run()

    st.subheader("📄 自动生成报告")
    st.text(report)

    st.subheader("📊 图表")
    for img in ["pH.png", "Mn.png", "COD.png"]:
        st.image(img)
