import pandas as pd
from analyzer import DataAnalyzer
from visualizer import Visualizer
from report_generator import ReportGenerator

class EnvDataAgent:
    def __init__(self, file_path):
        self.df = pd.read_csv(file_path)

    def run(self):
        analyzer = DataAnalyzer(self.df)

        stats = analyzer.basic_stats()
        anomalies = analyzer.detect_anomalies()
        trends = analyzer.trend_analysis()

        visualizer = Visualizer(self.df)
        visualizer.plot_all()

        report_gen = ReportGenerator(stats, anomalies, trends)
        report = report_gen.generate()

        with open("report.txt", "w", encoding="utf-8") as f:
            f.write(report)

        return report
