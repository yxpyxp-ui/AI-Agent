import pandas as pd

class DataAnalyzer:
    def __init__(self, df):
        self.df = df

    def basic_stats(self):
        return self.df.describe()

    def detect_anomalies(self):
        anomalies = {}
        thresholds = {
            "pH": (6.5, 8.5),
            "Mn": (0, 0.15),
            "COD": (0, 30)
        }
        for col, (low, high) in thresholds.items():
            anomalies[col] = self.df[(self.df[col] < low) | (self.df[col] > high)]
        return anomalies

    def trend_analysis(self):
        trends = {}
        for col in ["pH", "Mn", "COD"]:
            trends[col] = self.df[col].iloc[-1] - self.df[col].iloc[0]
        return trends
